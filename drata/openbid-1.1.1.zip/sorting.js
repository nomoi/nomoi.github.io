"use strict";

const makeSortingCtx = (imports) => {

	const {timeCtx} = imports;

	function selectTimes(chain) {
		return chain.flights.map(x => x.slice(3));
	}

	const getTimesOfChainFns = {
		arrl(chain) {
			return selectTimes(chain);
		},
		rept(chain) {
			const times = selectTimes(chain);
			times[0][0] = chain.rept;
			times[times.length-1][1] = chain.dend;

			return times;
		}
	};

	function getCostOfTimesFns(allNighterStart, allNighterEnd) {
		return (times) => times
			.map(x => timeCtx.calculateAllNighterOverlap(x[0], x[1], allNighterStart, allNighterEnd))
			.reduce(sum);
	}

	const sum = (a, b) => a + b;

	function calculateAllNighterCost(line, catalog, getAllNighterCostOfChain) {
		const pairings = line.pairingIds
			.filter(x => x !== undefined)
			.map(x => catalog.pairingIdToPairing.get(x));
		const costs = pairings.map(x => x.chains.map(getAllNighterCostOfChain).reduce(sum));
		return costs.reduce(sum);
	}

	function calculateCosts(catalog, settings) {

		const getTimesOfChain = getTimesOfChainFns[settings.intervalMode];
		const getAllNighterCostOfTimes = getCostOfTimesFns(settings.allNighter.start, settings.allNighter.end);
		const getAllNighterCostOfChain = (chain) => {
			const times = getTimesOfChain(chain);
			return getAllNighterCostOfTimes(times);
		};

		const {lines} = catalog;
		const lineToCosts = new Map();

		for (let i = 0; i < lines.length; i++) {
			lineToCosts.set(lines[i], {
				allNighter: calculateAllNighterCost(lines[i], catalog, getAllNighterCostOfChain)
			});
		}

		return lineToCosts;
	}

	return {
		calculateCosts
	};
};
