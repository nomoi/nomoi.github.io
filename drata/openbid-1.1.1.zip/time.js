"use strict";

// note that the native Date object is slightly abused
// for cases where only a time is needed (eg representing the all-nighter sliders)
// the year, month, and day are ignored

const makeTimeCtx = () => {

	function readTime(x) {
		console.assert(typeof x === "string");
		console.assert(x.length === 4);
		console.assert(/^\s*\d+$/.test(x));

		x = x.trimLeft();

		if (x.length < 4) {
			x = "0".repeat(4 - x.length) + x;
		}

		const hour = x.slice(0, 2);
		const minute = x.slice(2);
		return [hour, minute].map(x => Number.parseInt(x));
	}

	function calculateAllNighterOverlap(...times) {
		console.assert(times.length === 4);
		for (let x of times) {
			console.assert(Array.isArray(x));
			console.assert(x.length === 2);
			if (!Number.isInteger(x[0])) debugger;
			console.assert(Number.isInteger(x[0]));
			console.assert(Number.isInteger(x[1]));
		}

		console.assert(times[2][0] >= 18 && times[2][0] < 24); // slider start
		if (!(times[3][0] >= 0 && times[3][0] <= 6)) debugger; // slider end
		console.assert(times[3][0] >= 0 && times[3][0] <= 6); // slider end

		let [flightStart, flightEnd, allNighterStart, allNighterEnd] = times.map(x => x[0] + x[1] / 60);

		// normalizing slider end
		allNighterEnd += 24;

		if (flightStart > flightEnd) {
			flightEnd += 24;
		}

		const isNotIntersecting = flightEnd < allNighterStart || flightStart > allNighterEnd;
		if (!isNotIntersecting) {
			return Math.min(flightEnd, allNighterEnd) - Math.max(flightStart, allNighterStart);
		}
		
		return 0;
	}

	return {
		readTime,
		calculateAllNighterOverlap
	};
};

if (typeof module !== "undefined" && module.exports) {
	module.exports = makeTimeCtx;
}
