"use strict";

window.onload = function() {

	const timeCtx = makeTimeCtx();

	const lineCtx = makeLineCtx();
	const pairingCtx = makePairingCtx({timeCtx});
	const parserCtx = makeParserCtx({lineCtx, pairingCtx});
	const catalogCtx = makeCatalogCtx({parserCtx});

	const settingCtx = makeSettingCtx({timeCtx});
	const inputCtx = makeInputCtx({settingCtx});
	const outputCtx = makeOutputCtx({document});

	const sortingCtx = makeSortingCtx({timeCtx});
	const {Updater} = makeUpdatingCtx({sortingCtx, catalogCtx, outputCtx});

	const pre = document.querySelector("pre");
	const inputSection = document.querySelector("#input-section");
	const outputSection = document.querySelector("#output-section");

	const catalogString = pre.textContent;
	const updater = new Updater(catalogString, outputSection);

	inputCtx.setup(updater, inputSection);
};
