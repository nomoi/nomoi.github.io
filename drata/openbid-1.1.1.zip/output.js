"use strict";

const makeOutputCtx = (imports) => {

	function makeLineNode(line, daysInLine, pairingIdToPairing) {
		const lineNode = document.createElement("div");

		const header = document.createElement("h3");
		header.classList.add("line-header");
		header.textContent = "Line " + line.id;

		lineNode.appendChild(header);

		const content = document.createElement("div");
		content.classList.add("line-content");

		const table = document.createElement("table");
		const thead = document.createElement("thead");
		const trhead = document.createElement("tr");

		for (let day of daysInLine) {
			const th = document.createElement("th");
			th.textContent = day;
			trhead.appendChild(th);
		}

		thead.appendChild(trhead);
		table.appendChild(thead);

		const tr = document.createElement("tr");

		for (let placeStr of line.dutyEndPlaces) {
			const td = document.createElement("td");
			td.textContent = placeStr;
			tr.appendChild(td);
		}

		const tbody = document.createElement("tbody");
		tbody.appendChild(tr);
		table.appendChild(tbody);

		content.appendChild(table);

		lineNode.appendChild(content);

		return lineNode;
	}

	function setupListUI(outputSection) {
		$(outputSection).accordion({
			header: "> div > h3",
			collapsible: true
		}).sortable({
			axis: "y",
			handle: "h3",
			stop: function(event, ui) {
				ui.item.children("h3").triggerHandler("focusout");
				$(this).accordion("refresh");
			}
		});
	}

	function setup(catalog, outputSection) {
		const lineToNode = new Map();
		for (let line of catalog.lines) {
			const lineNode = makeLineNode(line, catalog.daysInLine, catalog.pairingIdToPairing);
			outputSection.appendChild(lineNode);

			lineToNode.set(line, lineNode);
		}

		setupListUI(outputSection);

		return lineToNode;
	}

	return {
		setup
	};
};	
