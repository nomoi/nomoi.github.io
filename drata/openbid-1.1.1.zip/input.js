"use strict";

// "menu" might be better name

const makeInputCtx = (imports) => {

	const {datetimeCtx, settingCtx} = imports;
	const {Setting} = settingCtx;

	function setup(updater, inputSection) {

		const allNighterSlider = inputSection.querySelector("#all-nighter-slider");
		const intervalMode = inputSection.querySelector("#interval-mode");

		function padWithZero(x) {
			if (String(x).length === 1) {
				return '0' + x;
			}
			return String(x);
		}

		// TODO: convert setting from class to a pure ctx
		const setting = new Setting(allNighterSlider, intervalMode);

		function updateValue(ui) {
			const hours = (18 + Math.floor(ui.value)) % 24;
			const minutes = 60 * (ui.value % 1);
			const time = [padWithZero(hours), padWithZero(minutes)];
			$(ui.handle).attr('data-raw-value', time.join(''));
			$(ui.handle).attr('data-value', time.join(':'));
		}

		const initialValues = [2, 6.5];

		$(allNighterSlider).slider({
			range: true,
			min: 0,
			max: 12,
			step: 0.25,
			values: initialValues,
			slide: function(event, ui) {
				if (ui.values[0] >= 6) {
					return false; // don't allow it to update
				}

				if (ui.values[1] <= 6) {
					return false;
				}

				updateValue(ui);
				updater.run(setting.collect());
			},
			create: function(event, ui) {
				$.each(initialValues, function(i, v) {
					updateValue({
						value: v,
						handle: $('.ui-slider-handle').eq(i)
					});
				});
			}
		});

		$("#amount").val("$" + $(allNighterSlider).slider("values", 0) + " - $" + $(allNighterSlider).slider("values", 1));

		const sliderMax = $(allNighterSlider).slider("option", "max");
		const tickMarkSpacing = 100 / sliderMax;

		for (let i = 1; i < sliderMax; i++) {
			$("<span class='ui-slider-tick-hour-mark'></span>").css("left", (tickMarkSpacing * i) + "%").appendTo($(allNighterSlider));
		}

		for (let radio of intervalMode.querySelectorAll("input[type=radio]")) {
			radio.onchange = function(event) {
				updater.run(setting.collect());
			}
		}

		updater.run(setting.collect());
	}

	return {
		setup
	};
};
