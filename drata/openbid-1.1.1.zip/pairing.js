"use strict";

const makePairingCtx = (imports) => {

	const {timeCtx} = imports;
	const {readTime} = timeCtx;

	const FLIGHT = /(\d|MO|TU|WE|TH|FR|SA|SU).{14}(\w{3})-(\w{3})  (\d{4}) (\d{4})/g;
	const REPT = /REPT: (\d{4})L/g;
	const DEND = /D-END: (.{4})L/g;

	const DAYS_OF_WEEK = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"];

	function executeRegex(re, str) {
		const matches = [];
		re.lastIndex = 0;

		let match;
		while((match = re.exec(str)) !== null) {
			matches.push(match);
		}

		return matches;
	}

	function readChains(entry) {
		const chainSections = entry.split(/REPT: /).slice(1);

		const chains = chainSections.map(x => {
			return {
				rept: readTime(x.match(/^\d{4}/)[0]),
				dend: readTime(x.match(/D-END: (.{4})L/)[1]),
				flights: executeRegex(FLIGHT, x).map(x => x.slice(1)) // day, origin, destination, DEPL, ARRL
			};
		});

		const firstIndex = DAYS_OF_WEEK.indexOf(chains[0].flights[0][0]);

		// assuming no pairing goes as long as 7 days
		for (let chain of chains) {
			const {flights} = chain;
			for (let i = 0; i < flights.length; i++) {
				if (firstIndex > -1) {
					const diff = DAYS_OF_WEEK.indexOf(flights[i][0]) - firstIndex;
					flights[i][0] = (diff + 7) % 7;
				} else { 
					flights[i][0] = Number.parseInt(flights[i][0]) - 1;
				}

				flights[i][3] = readTime(flights[i][3]); // depl
				flights[i][4] = readTime(flights[i][4]); // arrl
			}
		}

		return chains;
	}

	class Pairing {
		constructor(entry) {
			console.assert(typeof entry === "string");
			this.id = Number.parseInt(entry.match(/   S(\d{5})/)[1]);
			console.assert(Number.isInteger(this.id));

			this.chains = readChains(entry);
		}
	}

	return {
		Pairing
	};
};

if (typeof module !== "undefined" && module.exports) {
	module.exports = makePairingCtx;
}
