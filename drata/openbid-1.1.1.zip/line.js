"use strict";

const makeLineCtx = () => {

	const PAIRING_ID = /\d{5}/g;

	const collectPairingIds = (rows) => rows
		.map(x => x.slice(23)) // this is so the following filter can work
		.filter(x => !/[^\s\d]/.test(x)) // keep rows that have nothing but pairing numbers
		.map(x => { // there's either one or two such rows

			const pairingIds = [];

			PAIRING_ID.lastIndex = 0;
			let match;
			while ((match = PAIRING_ID.exec(x)) !== null) {
				const index = (PAIRING_ID.lastIndex-1) / 4 - 1;
				pairingIds[index] = Number.parseInt(match[0]);
			}

			return pairingIds;
		})
		.reduce((a, b) => { // combining into a single holder
			b.forEach((e, i) => {
				if (e !== null) {
					a[i] = e;
				}
			});

			return a;
		});

	// TODO: might be nicer to derive these from the pairings themselves
	const readDutyEndPlaces = (entry) => entry
		.match(/^OFF.*$/m)[0]
		.slice(27).split(/\s/)
		.filter(x => x.length > 0);

	class Line {
		constructor(entry) {
			console.assert(typeof entry === "string");
			this.id = Number.parseInt(entry.match(/LINE +(\d+) /)[1]);
			console.assert(Number.isInteger(this.id));

			this.pairingIds = collectPairingIds(entry.split('\n').slice(1, -1));
			this.dutyEndPlaces = readDutyEndPlaces(entry);
		}
	}

	return {
		Line
	};
};

if (typeof module !== "undefined" && module.exports) {
	module.exports = makeLineCtx;
}
