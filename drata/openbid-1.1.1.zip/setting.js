"use strict";

const makeSettingCtx = (imports) => {

	const {timeCtx} = imports;
	const {readTime} = timeCtx;

	class Setting {
		constructor(allNighterSlider, intervalMode) {
			this.allNighterSlider = allNighterSlider;
			this.intervalMode = intervalMode;
		}

		collect() {
			const leftAllNighterSliderHandle = this.allNighterSlider.children[1];
			const rightAllNighterSliderHandle = this.allNighterSlider.children[2];

			const settings = {
				allNighter: {
					start: readTime(leftAllNighterSliderHandle.dataset.rawValue),
					end: readTime(rightAllNighterSliderHandle.dataset.rawValue)
				},
				intervalMode: null
			};

			const intervalModeData = new FormData(this.intervalMode);

			for (const entry of intervalModeData) {
				settings.intervalMode = entry[1];
			}

			return settings;
		}
	}

	return {
		Setting
	};
};
