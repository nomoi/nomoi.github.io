"use strict";

const makeParserCtx = (imports) => {

	const {lineCtx, pairingCtx} = imports;
	const {Line} = lineCtx;
	const {Pairing} = pairingCtx;

	const readSections = (catalogString) => catalogString
		.split(/\*\*\*/g)
		.slice(1) // skipping empty
		.map(x => x.trim());

	const readLines = (section) => section
		.split(/-{156}/g)
		.slice(1, -1) // skipping empty
		.map(x => new Line(x));

	const readPairings = (section) => {
		const pairings = section
			.split(/={132}/g)
			.slice(2, -1) // skipping irrelevant and empty
			.map(x => new Pairing(x));

		const pairingIdToPairing = new Map();

		for (let pairing of pairings) {
			pairingIdToPairing.set(pairing.id, pairing);
		}

		return pairingIdToPairing;
	};

	function readDaysInLine(lineSection) {
		const match = lineSection.match(/      1.*$/m);
		return match[0].split(/\b/).filter(x => /\d/.test(x));
	}

	function readDate(pairingSection) {
		const [, month, year] = pairingSection.match(/==\n(\w+)\s+(\d{4})/);
		return [month, year];
	}

	return {
		readSections,
		readDate,
		readDaysInLine,
		readPairings,
		readLines
	};
};

if (typeof module !== "undefined" && module.exports) {
	module.exports = makeParserCtx;
}
