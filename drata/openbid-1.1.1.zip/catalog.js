"use strict";

const makeCatalogCtx = (imports) => {

	const {parserCtx, document} = imports;

	// stores lines and pairings data
	// and provides ways to normalize this data based on settings
	class Catalog {
		constructor(catalogString) {

			const [lineSection, pairingSection] = parserCtx.readSections(catalogString);

			this.daysInLine = parserCtx.readDaysInLine(lineSection);
			this.datetime = parserCtx.readDate(pairingSection);

			this.lines = parserCtx.readLines(lineSection);
			this.pairingIdToPairing = parserCtx.readPairings(pairingSection);

			console.log(this);
		}
	}

	return {
		Catalog
	};
};
