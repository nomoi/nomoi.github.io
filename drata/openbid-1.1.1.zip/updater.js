"use strict";

const makeUpdatingCtx = (imports) => {

	const {sortingCtx, catalogCtx, outputCtx} = imports;
	const {Catalog} = catalogCtx;

	class Updater {
		constructor(catalogString, outputSection) {
			this.catalog = new Catalog(catalogString);
			this.outputSection = outputSection;

			this.lineToNode = outputCtx.setup(this.catalog, outputSection);
		}

		run(settings) {
			console.log(settings);
			const lineToCosts = sortingCtx.calculateCosts(this.catalog, settings);
			console.log(lineToCosts);

			const lines = [...this.catalog.lines]; // may not need to copy
			lines.sort((a, b) => {
				return lineToCosts.get(a).allNighter - lineToCosts.get(b).allNighter;
			});

			for (let line of lines) {
				const lineNode = this.lineToNode.get(line);
				lineNode.classList.toggle("active", lineToCosts.get(line).allNighter === 0);
				this.outputSection.appendChild(lineNode);
			}
		}
	}

	return {
		Updater
	};
};
